package service;

import java.sql.SQLException;

// ExamService.java
import java.util.List;

import dao.QuestionDAO;
import model.Question;

public class ExamService {
    private QuestionDAO questionDAO;

    public ExamService() {
        questionDAO = new QuestionDAO();
    }

    public List<Question> getQuestionsForExam(int examId) {
        try {
            return questionDAO.getQuestionsByExamId(examId);
        } catch (SQLException e) {
            e.printStackTrace();
            return null;
        }
    }

    public int calculateScore(List<Question> questions, List<Integer> userAnswers) {
        int score = 0;
        for (int i = 0; i < questions.size(); i++) {
            if (questions.get(i).getCorrectOption() == userAnswers.get(i)) {
                score++;
            }
        }
        return score;
    }
}
