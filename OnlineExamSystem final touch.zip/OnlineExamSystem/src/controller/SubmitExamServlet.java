package controller;

import javax.servlet.*;
import javax.servlet.http.*;
import model.Question;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

public class SubmitExamServlet extends HttpServlet {

    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        HttpSession session = request.getSession();
        List<Question> questions = (List<Question>) session.getAttribute("questions");

        if (questions == null) {
            request.setAttribute("errorMessage", "No questions found. Please start a new exam.");
            RequestDispatcher dispatcher = request.getRequestDispatcher("error.jsp");
            dispatcher.forward(request, response);
            return;
        }

        // Retrieve user's answers from the form
        List<Integer> userAnswers = new ArrayList<>();
        boolean allAnswered = true;

        for (int i = 0; i < questions.size(); i++) {
            String answerStr = request.getParameter("question" + i);

            if (answerStr == null) {
                allAnswered = false; // A question was not answered
                break;
            }

            try {
                userAnswers.add(Integer.parseInt(answerStr)); // Parse and add the answer
            } catch (NumberFormatException e) {
                allAnswered = false; // Invalid or missing answer
                break;
            }
        }

        // If any question is left unanswered, redirect to error page
        if (!allAnswered) {
            request.setAttribute("errorMessage", "Please answer all questions before submitting.");
            RequestDispatcher dispatcher = request.getRequestDispatcher("error.jsp");
            dispatcher.forward(request, response);
            return;
        }

        // Store user's answers in session
        session.setAttribute("userAnswers", userAnswers);

        // Check if the user clicked 'Submit'
        if ("submit".equals(request.getParameter("action"))) {
            // Calculate score and store it in session
            int score = calculateScore(questions, userAnswers);
            session.setAttribute("score", score);

            // Redirect to result.jsp
            response.sendRedirect("result.jsp");
        } else {
            // If navigating to next or previous question, simply redirect back to exam.jsp
            response.sendRedirect("exam.jsp?currentIndex=" + request.getParameter("currentIndex"));
        }
    }

    // Method to calculate the score based on user's answers
    private int calculateScore(List<Question> questions, List<Integer> userAnswers) {
        int score = 0;
        for (int i = 0; i < questions.size(); i++) {
            if (userAnswers.get(i) != null && userAnswers.get(i) == questions.get(i).getCorrectOption()) {
                score++;
            }
        }
        return score;
    }
}
