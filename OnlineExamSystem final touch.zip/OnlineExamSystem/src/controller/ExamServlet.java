package controller;

import javax.servlet.*;
import javax.servlet.http.*;
import model.Question;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

public class ExamServlet extends HttpServlet {

    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        try {
            // Get the exam ID from the request
            int examId = Integer.parseInt(request.getParameter("examId"));
            
            // Get the questions based on the examId
            List<Question> questions = getQuestionsForExam(examId);

            // Store the questions in the session
            HttpSession session = request.getSession();
            session.setAttribute("questions", questions);
            
            // Redirect to the exam page (exam.jsp)
            response.sendRedirect("exam.jsp"); // Ensure this JSP exists
        } catch (NumberFormatException e) {
            // Handle invalid exam ID format
            request.setAttribute("errorMessage", "Invalid exam ID.");
            RequestDispatcher dispatcher = request.getRequestDispatcher("error.jsp");
            dispatcher.forward(request, response);
        }
    }

    // Method to retrieve questions based on the exam ID
    private List<Question> getQuestionsForExam(int examId) {
        List<Question> questions = new ArrayList<>();

        // Sample questions for Exam 1
        if (examId == 1) {
            questions.add(new Question(1, 1, "What is the capital of France?", "Paris", "London", "Berlin", "Madrid", 1));
            questions.add(new Question(2, 1, "What is 2 + 2?", "3", "4", "5", "6", 2));
            questions.add(new Question(3, 1, "What is the chemical symbol for water?", "H2", "O2", "H2O", "HO2", 3));
            questions.add(new Question(4, 1, "What is the largest mammal in the world?", "Elephant", "Blue Whale", "Giraffe", "Shark", 2));
            questions.add(new Question(5, 1, "What is the currency of Japan?", "Dollar", "Euro", "Yen", "Won", 3));
            // Add more questions if needed...
        }

        // Questions for Exam 2
        else if (examId == 2) {
            questions.add(new Question(1, 2, "Who wrote 'Romeo and Juliet'?", "William Shakespeare", "Charles Dickens", "Jane Austen", "Leo Tolstoy", 1));
            questions.add(new Question(2, 2, "What is the largest planet in our solar system?", "Earth", "Jupiter", "Mars", "Venus", 2));
            questions.add(new Question(3, 2, "What is the process by which plants make their food?", "Respiration", "Digestion", "Photosynthesis", "Fermentation", 3));
            questions.add(new Question(4, 2, "What is the freezing point of water?", "0 degrees Celsius", "32 degrees Fahrenheit", "100 degrees Celsius", "0 degrees Fahrenheit", 1));
            // Add more questions if needed...
        }

        return questions;
    }

    // Method to calculate the score based on the user's answers
    public int calculateScore(List<Question> questions, List<Integer> userAnswers) {
        int score = 0;
        for (int i = 0; i < questions.size(); i++) {
            if (userAnswers.get(i) != null && userAnswers.get(i) == questions.get(i).getCorrectOption()) {
                score++;
            }
        }
        return score;
    }
}
