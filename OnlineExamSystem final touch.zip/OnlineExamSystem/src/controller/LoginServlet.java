package controller;

import javax.servlet.*;
import javax.servlet.http.*;
import dao.UserDAO;
import model.User;
import java.io.IOException;

public class LoginServlet extends HttpServlet {
    private UserDAO userDAO;

    @Override
    public void init() {
        // Initialize userDAO instance
        userDAO = new UserDAO();
    }

    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response) 
            throws ServletException, IOException {
        
        // Get the username and password parameters from the login form
        String username = request.getParameter("username"); // should match the form field name
        String password = request.getParameter("password"); // should match the form field name
        
        User user = null;
        try {
            // Call the instance method, not the class method
            user = userDAO.getUserByUsernameAndPassword(username, password);
        } catch (Exception e) {
            e.printStackTrace(); // Log the exception for debugging
        }

        // Check if the user is found
        if (user != null) {
            HttpSession session = request.getSession();
            session.setAttribute("user", user);
            response.sendRedirect("exam-list.jsp"); // Redirect to the exam list page after successful login
        } else {
            response.sendRedirect("login.jsp?error=invalid"); // Redirect back to the login page with error message
        }
    }
}
