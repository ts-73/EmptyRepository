// UserDAO.java
package dao;

import model.User;

public class UserDAO {

    // Simulating a database fetch operation
    public static User getUserByUsernameAndPassword(String username, String password) {
        // In a real scenario, you would query the database here
        if (username.equals("root") && password.equals("tiger")) {
            return new User(1, "root", "tiger", "admin");
        }
        return null;
    }
}
