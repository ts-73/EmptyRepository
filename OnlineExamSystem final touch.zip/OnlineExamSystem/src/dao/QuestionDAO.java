package dao;

import model.Question; // Ensure you import the Question model class
import utils.DatabaseConnection;

import java.sql.*;
import java.util.ArrayList;
import java.util.List;

public class QuestionDAO {

    public List<Question> getQuestionsByExamId(int examId) throws SQLException {
        String query = "SELECT * FROM questions WHERE exam_id=?";
        List<Question> questions = new ArrayList<>();

        // Use try-with-resources to ensure proper resource management
        try (Connection conn = DatabaseConnection.getConnection();
             PreparedStatement pstmt = conn.prepareStatement(query)) {
             
            pstmt.setInt(1, examId);
            try (ResultSet rs = pstmt.executeQuery()) {
                while (rs.next()) {
                    // Create Question object using a constructor or setters
                    Question question = new Question(
                        rs.getInt("question_id"),
                        rs.getInt("exam_id"),
                        rs.getString("question_text"),
                        rs.getString("option1"),
                        rs.getString("option2"),
                        rs.getString("option3"),
                        rs.getString("option4"),
                        rs.getInt("correct_option")
                    );
                    questions.add(question);
                }
            }
        } catch (SQLException e) {
            // Log the exception or rethrow it with more context
            System.err.println("Error retrieving questions: " + e.getMessage());
            throw e; // Optionally rethrow if you want higher-level handling
        }

        return questions;
    }
}
