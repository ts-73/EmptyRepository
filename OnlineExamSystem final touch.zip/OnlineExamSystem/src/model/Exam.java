package model;

public class Exam {
    private int examId;       // Unique identifier for the exam
    private String examName;  // Name of the exam

    // Constructor to initialize the Exam object
    public Exam(int examId, String examName) {
        this.examId = examId;
        this.examName = examName;
    }

    // Getter for examId
    public int getExamId() {
        return examId;
    }

    // Setter for examId
    public void setExamId(int examId) {
        this.examId = examId;
    }

    // Getter for examName
    public String getExamName() {
        return examName;
    }

    // Setter for examName
    public void setExamName(String examName) {
        this.examName = examName;
    }
}
