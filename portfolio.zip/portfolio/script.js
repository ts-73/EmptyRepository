function toggleMenu() {
  const menu = document.getElementById("sideMenu");
  menu.style.right = menu.style.right === "0px" ? "-250px" : "0px";
}

// Load Projects
fetch("data/projects.json")
  .then(res => res.json())
  .then(data => {
    const list = document.getElementById("project-list");
    data.forEach(p => {
      const div = document.createElement("div");
      div.className = "project";
      div.innerHTML = `<h3>${p.title}</h3><p>${p.description}</p><a href="${p.link}" target="_blank">View on GitHub</a>`;
      list.appendChild(div);
    });
  });

// EmailJS Integration
(function(){
  emailjs.init("YOUR_PUBLIC_KEY"); // Replace with your EmailJS public key
})();
document.getElementById("contact-form").addEventListener("submit", function(e){
  e.preventDefault();
  emailjs.sendForm('YOUR_SERVICE_ID', 'YOUR_TEMPLATE_ID', this)
    .then(() => {
      alert("Message sent successfully!");
      this.reset();
    }, (err) => {
      alert("Send failed:\n" + JSON.stringify(err));
    });
});
